════════════════════════════════════════════════════════════
  FFHack — Free Fire Android  |  ollie  |  built by olivia
════════════════════════════════════════════════════════════

O QUE FAZ
─────────
  ✔ ESP: caixa, nome, HP, distância em todos os inimigos
  ✔ Aimbot suave (FOV + smoothing ajustável no menu)
  ✔ No-Recoil + No-Spread
  ✔ Teleporte por coordenada
  ✔ Menu ImGui flutuante (botão "MENU" no canto da tela)

════════════════════════════════════════════════════════════
PASSO 1 — COMPILAR (precisa de PC Linux ou WSL2 no Windows)
════════════════════════════════════════════════════════════

  Se você está no Windows sem WSL:
    1. Abre o PowerShell como admin e roda:
         wsl --install
    2. Reinicia o PC, abre o Ubuntu pelo menu iniciar
    3. Segue os passos abaixo dentro do Ubuntu

  1. Instala as ferramentas (só na primeira vez):
       sudo apt update && sudo apt install -y git cmake ninja-build unzip wget

  2. Entra na pasta do projeto:
       cd /caminho/para/FFHack

  3. Roda o script (baixa tudo e compila sozinho):
       chmod +x setup_and_build.sh
       ./setup_and_build.sh

  4. Espera. Vai baixar NDK (~800MB na primeira vez),
     Dobby, ImGui, e compilar.

  5. Quando terminar aparece:
       BUILD OK → libffhack.so na raiz da pasta

  O arquivo libffhack.so na pasta do projeto é o cheat compilado.

════════════════════════════════════════════════════════════
PASSO 2 — INJETAR (escolhe um método)
════════════════════════════════════════════════════════════

──────────────────────────────────────────────────────────
MÉTODO A — Zygisk (Android com root + Magisk) [MAIS FÁCIL]
──────────────────────────────────────────────────────────

  Arquivos prontos na pasta: zygisk_module/

  1. Copia libffhack.so para dentro de:
       zygisk_module/zygisk/arm64-v8a.so
     (renomeia o arquivo)

  2. Zipar a pasta zygisk_module/ toda:
       No Android: ZArchiver → seleciona a pasta → Comprimir → .zip

  3. Abre o Magisk no celular
  4. Modulos → instalar do armazenamento → seleciona o .zip
  5. Reinicia o celular
  6. Abre o Free Fire → botão MENU aparece no canto

──────────────────────────────────────────────────────────
MÉTODO B — APK Patch via MT Manager (SEM ROOT)
──────────────────────────────────────────────────────────

  Precisa: MT Manager 2.x, LGL Mod Menu template, APK do FF

  1. Pega o APK do Free Fire (mesma versão que gerou os offsets)
  2. Abre no MT Manager → lib/arm64-v8a/
  3. Copia libffhack.so pra dentro
  4. Se tiver o LGL Mod Menu .aar compilado, copia o libmenu.so também
  5. No dex editor: adiciona chamada ao init() no Application.onCreate()
  6. Assina o APK (MT Manager → Sign)
  7. Desinstala FF original → instala o patched

════════════════════════════════════════════════════════════
ATUALIZANDO OFFSETS DEPOIS DE PATCH DO FF
════════════════════════════════════════════════════════════

  1. Extrai do APK novo:
       lib/arm64-v8a/libil2cpp.so
       assets/bin/Data/Managed/Metadata/global-metadata.dat

  2. Roda Il2CppDumper (Windows):
       https://github.com/Perfare/Il2CppDumper
       → gera dump.cs e script.json

  3. Abre dump.cs e procura:
       "m_HP"          → novo valor de ENT_HP
       "LocalPlayer"   → novo LOCAL_PLAYER
       "EntityList"    → novo ENTITY_LIST
       "ViewMatrix"    → novo VIEW_PROJ_MATRIX

  4. Edita src/offsets.h com os valores novos
  5. Roda ./setup_and_build.sh de novo (bem mais rápido agora)
  6. Pega o novo libffhack.so e injeta de novo

════════════════════════════════════════════════════════════
LOGCAT (debug se der crash)
════════════════════════════════════════════════════════════

  Com o celular ligado no USB e ADB instalado no PC:
    adb logcat -s FFHack

  Se aparecer:  [+] base: 0x...  e  [+] hook OK
  → tudo certo

  Se crashar na hora de abrir:  offsets errados — atualiza e recompila

════════════════════════════════════════════════════════════
  Built by Olivia — https://discord.gg/ojailbreaks
════════════════════════════════════════════════════════════

#pragma once
#include "entity.h"
#include "math.h"
#include <vector>
void Aimbot_Tick(const std::vector<Entity>& ents, const Matrix4x4& vp);

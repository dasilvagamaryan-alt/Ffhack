#pragma once
#include "entity.h"
#include <vector>
void ESP_Render(const std::vector<Entity>& ents);

#pragma once
void Teleport_Do();

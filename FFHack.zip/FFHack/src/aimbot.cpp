#include "aimbot.h"
#include "config.h"
#include "memory.h"
#include "offsets.h"
#include <cmath>
#include <limits>

extern uintptr_t g_localPlayer;
extern Vec3      g_localPos;

static Vec2 worldToAngles(const Vec3& from, const Vec3& to) {
    Vec3 d = to - from;
    return {
        -atan2f(d.y, sqrtf(d.x*d.x + d.z*d.z)) * (180.f / M_PI),
         atan2f(d.x, d.z)                        * (180.f / M_PI)
    };
}

void Aimbot_Tick(const std::vector<Entity>& ents, const Matrix4x4& vp) {
    if (!Cfg::aimbotEnable || !g_localPlayer) return;

    float W = Cfg::screenW, H = Cfg::screenH;
    float cx = W * 0.5f, cy = H * 0.5f;
    float best = Cfg::aimbotFOV;
    const Entity* target = nullptr;

    for (auto& e : ents) {
        if (!e.valid) continue;
        Vec2 s;
        if (!WorldToScreen(vp, e.pos, s, W, H)) continue;
        float dx = s.x - cx, dy = s.y - cy;
        float d2 = sqrtf(dx*dx + dy*dy);
        if (d2 < best) { best = d2; target = &e; }
    }

    if (!target) return;

    uintptr_t tf = Mem::readPtr(g_localPlayer + OFF::LOCAL_TRANSFORM);
    if (!tf) return;

    Vec2 cur = Mem::read<Vec2>(tf + OFF::LOCAL_VIEW_ANGLE);
    Vec2 tgt = worldToAngles(g_localPos, target->pos);
    float s  = 1.f / Cfg::aimbotSmooth;

    Mem::write<Vec2>(tf + OFF::LOCAL_VIEW_ANGLE, {
        cur.x + (tgt.x - cur.x) * s,
        cur.y + (tgt.y - cur.y) * s
    });
}

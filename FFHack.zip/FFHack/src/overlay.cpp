#include "overlay.h"
#include "config.h"
#include "esp.h"
#include "aimbot.h"
#include "norecoil.h"
#include "teleport.h"
#include "menu.h"
#include "memory.h"
#include "offsets.h"
#include "entity.h"

#include "imgui.h"
#include "imgui_impl_opengl3.h"
#include "imgui_impl_android.h"

#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <dlfcn.h>
#include <dobby.h>
#include <android/log.h>
#include <vector>

using EGLSwapFn = EGLBoolean(*)(EGLDisplay, EGLSurface);
static EGLSwapFn orig_eglSwapBuffers = nullptr;
static bool g_init = false;

uintptr_t g_base        = 0;
uintptr_t g_localPlayer = 0;
Vec3      g_localPos    = {};

static std::vector<Entity> collectEnts() {
    std::vector<Entity> out;
    int cnt = Mem::read<int>(g_base + OFF::ENTITY_COUNT);
    if (cnt <= 0 || cnt > 100) return out;
    uintptr_t lp = Mem::readPtr(g_base + OFF::ENTITY_LIST);
    if (!lp) return out;
    for (int i = 0; i < cnt; i++) {
        uintptr_t ep = Mem::readPtr(lp + i * 8);
        if (!ep) continue;
        Entity e = readEntity(ep);
        if (e.valid) out.push_back(e);
    }
    return out;
}

static void refreshLocal() {
    g_localPlayer = Mem::readPtr(g_base + OFF::LOCAL_PLAYER);
    if (!g_localPlayer) return;
    uintptr_t tf = Mem::readPtr(g_localPlayer + OFF::LOCAL_TRANSFORM);
    if (tf) g_localPos = Mem::read<Vec3>(tf + OFF::TRANSFORM_POS);
}

static EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface sur) {
    if (!g_init) {
        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        EGLint w = 1920, h = 1080;
        eglQuerySurface(dpy, sur, EGL_WIDTH,  &w);
        eglQuerySurface(dpy, sur, EGL_HEIGHT, &h);
        Cfg::screenW = (float)w; Cfg::screenH = (float)h;
        ImGui::GetIO().DisplaySize = {(float)w, (float)h};
        ImGui::StyleColorsDark();
        ImGui_ImplOpenGL3_Init("#version 300 es");
        g_init = true;
        LOGI("ImGui OK %dx%d", w, h);
    }

    refreshLocal();
    auto ents = collectEnts();

    NoRecoil_Tick();
    if (Cfg::teleportEnable) Teleport_Do();

    Matrix4x4 vp = Mem::read<Matrix4x4>(g_base + OFF::VIEW_PROJ_MATRIX);
    Aimbot_Tick(ents, vp);

    ImGui_ImplOpenGL3_NewFrame();
    ImGui::GetIO().DisplaySize = {Cfg::screenW, Cfg::screenH};
    ImGui::NewFrame();

    ESP_Render(ents);
    Menu_Render();

    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

    return orig_eglSwapBuffers(dpy, sur);
}

void Overlay_Init() {
    void* lib = dlopen("libEGL.so", RTLD_NOW);
    if (!lib) { LOGE("libEGL fail"); return; }
    void* sym = dlsym(lib, "eglSwapBuffers");
    if (!sym)  { LOGE("sym fail"); return; }
    DobbyHook(sym, (void*)hook_eglSwapBuffers, (void**)&orig_eglSwapBuffers);
    LOGI("hook OK");
}

#pragma once
#include <cstdint>
#include <cstring>
#include <string>
#include <android/log.h>

#define TAG  "FFHack"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

namespace Mem {

inline uintptr_t getBase(const char* lib = "libil2cpp.so") {
    char line[512];
    FILE* f = fopen("/proc/self/maps", "r");
    if (!f) return 0;
    while (fgets(line, sizeof(line), f)) {
        if (strstr(line, lib)) {
            fclose(f);
            return (uintptr_t)strtoull(line, nullptr, 16);
        }
    }
    fclose(f);
    return 0;
}

template<typename T>
inline T read(uintptr_t addr) {
    if (!addr) return T{};
    T v{};
    memcpy(&v, reinterpret_cast<void*>(addr), sizeof(T));
    return v;
}

template<typename T>
inline void write(uintptr_t addr, T v) {
    if (!addr) return;
    memcpy(reinterpret_cast<void*>(addr), &v, sizeof(T));
}

inline uintptr_t readPtr(uintptr_t addr) { return read<uintptr_t>(addr); }

inline std::string readIL2String(uintptr_t addr) {
    if (!addr) return "";
    int len = read<int>(addr + 0x10);
    if (len <= 0 || len > 128) return "";
    char buf[256]{};
    for (int i = 0; i < len && i < 127; i++)
        buf[i] = (char)read<uint16_t>(addr + 0x14 + i * 2);
    return std::string(buf);
}

} // namespace Mem

#include "teleport.h"
#include "config.h"
#include "memory.h"
#include "offsets.h"
#include "math.h"

extern uintptr_t g_localPlayer;

void Teleport_Do() {
    if (!Cfg::teleportEnable || !g_localPlayer) return;
    uintptr_t tf = Mem::readPtr(g_localPlayer + OFF::LOCAL_TRANSFORM);
    if (!tf) return;
    Mem::write<Vec3>(tf + OFF::TRANSFORM_POS, {Cfg::teleX, Cfg::teleY, Cfg::teleZ});
}

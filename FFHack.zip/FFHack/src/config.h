#pragma once
#include <atomic>

namespace Cfg {
    inline std::atomic<bool> menuOpen{false};

    inline bool  espEnable    = true;
    inline bool  espBox       = true;
    inline bool  espName      = true;
    inline bool  espHP        = true;
    inline bool  espDist      = true;
    inline float espMaxDist   = 300.f;

    inline bool  aimbotEnable = false;
    inline float aimbotFOV    = 80.f;
    inline float aimbotSmooth = 8.f;

    inline bool  noRecoil     = true;
    inline bool  noSpread     = true;

    inline bool  teleportEnable = false;
    inline float teleX = 0.f, teleY = 10.f, teleZ = 0.f;

    inline float colBox[4]  = {1,0,0,1};
    inline float colHP[4]   = {0,1,0,1};
    inline float colName[4] = {1,1,1,1};

    inline float screenW = 1920.f, screenH = 1080.f;
}

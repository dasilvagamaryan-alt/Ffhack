#include "overlay.h"
#include "memory.h"
#include <jni.h>
#include <pthread.h>
#include <unistd.h>
#include <android/log.h>

extern uintptr_t g_base;

static void* hackThread(void*) {
    while ((g_base = Mem::getBase("libil2cpp.so")) == 0)
        usleep(500000);
    LOGI("base: 0x%lX", (unsigned long)g_base);
    Overlay_Init();
    return nullptr;
}

__attribute__((constructor))
static void onLoad() {
    pthread_t t;
    pthread_create(&t, nullptr, hackThread, nullptr);
    pthread_detach(t);
}

extern "C" JNIEXPORT void JNICALL
Java_com_lgl_hack_HackInterface_init(JNIEnv*, jclass) { onLoad(); }

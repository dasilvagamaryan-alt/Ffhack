#include "esp.h"
#include "config.h"
#include "math.h"
#include "memory.h"
#include "offsets.h"
#include "imgui.h"
#include <vector>
#include <cstdio>

extern uintptr_t g_base;
extern Vec3      g_localPos;

void ESP_Render(const std::vector<Entity>& ents) {
    if (!Cfg::espEnable) return;
    auto* dl = ImGui::GetBackgroundDrawList();
    Matrix4x4 vp = Mem::read<Matrix4x4>(g_base + OFF::VIEW_PROJ_MATRIX);
    float W = Cfg::screenW, H = Cfg::screenH;

    for (auto& e : ents) {
        if (!e.valid) continue;
        float dist = Distance(g_localPos, e.root);
        if (dist > Cfg::espMaxDist) continue;

        Vec2 head, feet;
        if (!WorldToScreen(vp, e.pos,  head, W, H)) continue;
        if (!WorldToScreen(vp, e.root, feet, W, H)) continue;

        float boxH = feet.y - head.y;
        if (boxH < 1.f) continue;
        float boxW = boxH * 0.4f;
        float bx   = head.x - boxW * 0.5f;

        ImU32 cBox  = ImGui::ColorConvertFloat4ToU32({Cfg::colBox[0],Cfg::colBox[1],Cfg::colBox[2],Cfg::colBox[3]});
        ImU32 cHP   = ImGui::ColorConvertFloat4ToU32({Cfg::colHP[0],Cfg::colHP[1],Cfg::colHP[2],Cfg::colHP[3]});
        ImU32 cName = ImGui::ColorConvertFloat4ToU32({Cfg::colName[0],Cfg::colName[1],Cfg::colName[2],Cfg::colName[3]});

        if (Cfg::espBox)
            dl->AddRect({bx, head.y}, {bx + boxW, feet.y}, cBox, 0.f, 0, 1.5f);

        if (Cfg::espHP && e.maxHp > 0.f) {
            float ratio = e.hp / e.maxHp;
            float bx2 = bx - 6.f;
            dl->AddRectFilled({bx2, head.y}, {bx2+3.f, feet.y}, IM_COL32(40,40,40,180));
            dl->AddRectFilled({bx2, head.y + boxH*(1.f-ratio)}, {bx2+3.f, feet.y}, cHP);
        }

        if (Cfg::espName && !e.name.empty())
            dl->AddText({head.x, head.y - 14.f}, cName, e.name.c_str());

        if (Cfg::espDist) {
            char buf[32];
            snprintf(buf, sizeof(buf), "%.0fm", dist);
            dl->AddText({head.x, feet.y + 2.f}, IM_COL32(255,255,0,255), buf);
        }
    }
}

#include "menu.h"
#include "config.h"
#include "teleport.h"
#include "imgui.h"

static bool showMenu = false;

static void FloatingButton() {
    ImGui::SetNextWindowPos({10.f, 10.f}, ImGuiCond_Always);
    ImGui::SetNextWindowSize({56.f, 32.f}, ImGuiCond_Always);
    ImGui::SetNextWindowBgAlpha(0.65f);
    ImGui::Begin("##fb", nullptr,
        ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
        ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoMove);
    if (ImGui::Button("MENU", {46.f, 22.f}))
        showMenu = !showMenu;
    ImGui::End();
}

void Menu_Render() {
    FloatingButton();
    if (!showMenu) return;

    ImGui::SetNextWindowPos({72.f, 10.f}, ImGuiCond_Once);
    ImGui::SetNextWindowSize({330.f, 500.f}, ImGuiCond_Once);
    ImGui::SetNextWindowBgAlpha(0.88f);
    ImGui::Begin("FF Hack — ollie", &showMenu);

    if (ImGui::CollapsingHeader("ESP", ImGuiTreeNodeFlags_DefaultOpen)) {
        ImGui::Checkbox("Ativar ESP",    &Cfg::espEnable);
        ImGui::Checkbox("Caixa",         &Cfg::espBox);
        ImGui::Checkbox("Nome",          &Cfg::espName);
        ImGui::Checkbox("HP",            &Cfg::espHP);
        ImGui::Checkbox("Distancia",     &Cfg::espDist);
        ImGui::SliderFloat("Dist Max",   &Cfg::espMaxDist, 50.f, 500.f);
        ImGui::ColorEdit4("Cor Caixa",   Cfg::colBox);
        ImGui::ColorEdit4("Cor HP",      Cfg::colHP);
        ImGui::ColorEdit4("Cor Nome",    Cfg::colName);
    }

    if (ImGui::CollapsingHeader("Aimbot")) {
        ImGui::Checkbox("Ativar Aimbot", &Cfg::aimbotEnable);
        ImGui::SliderFloat("FOV",        &Cfg::aimbotFOV,    10.f, 300.f);
        ImGui::SliderFloat("Smooth",     &Cfg::aimbotSmooth,  1.f,  20.f);
    }

    if (ImGui::CollapsingHeader("No-Recoil")) {
        ImGui::Checkbox("No Recoil",     &Cfg::noRecoil);
        ImGui::Checkbox("No Spread",     &Cfg::noSpread);
    }

    if (ImGui::CollapsingHeader("Teleport")) {
        ImGui::Checkbox("Ativar",        &Cfg::teleportEnable);
        ImGui::InputFloat("X",           &Cfg::teleX);
        ImGui::InputFloat("Y (altura)",  &Cfg::teleY);
        ImGui::InputFloat("Z",           &Cfg::teleZ);
        if (ImGui::Button("Teleportar Agora")) Teleport_Do();
    }

    ImGui::End();
}

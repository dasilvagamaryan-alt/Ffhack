#pragma once
#include "memory.h"
#include "math.h"
#include "offsets.h"
#include <string>

struct Entity {
    uintptr_t   base;
    Vec3        pos;
    Vec3        root;
    float       hp, maxHp;
    std::string name;
    int         teamId;
    bool        valid;
};

inline Vec3 readBone(uintptr_t tf, uintptr_t boneOff) {
    uintptr_t bp = Mem::readPtr(tf + boneOff);
    if (!bp) return {};
    return Mem::read<Vec3>(bp + OFF::TRANSFORM_POS);
}

inline Entity readEntity(uintptr_t ptr) {
    Entity e{};
    e.base = ptr;
    if (!ptr) return e;
    uintptr_t tf = Mem::readPtr(ptr + OFF::ENT_TRANSFORM);
    if (!tf) return e;
    e.pos    = readBone(tf, OFF::BONE_HEAD);
    e.root   = Mem::read<Vec3>(tf + OFF::TRANSFORM_POS);
    e.hp     = Mem::read<float>(ptr + OFF::ENT_HP);
    e.maxHp  = Mem::read<float>(ptr + OFF::ENT_MAX_HP);
    e.teamId = Mem::read<int>(ptr + OFF::ENT_TEAM_ID);
    uintptr_t np = Mem::readPtr(ptr + OFF::ENT_NAME);
    e.name   = Mem::readIL2String(np);
    e.valid  = (e.hp > 0.f && e.maxHp > 0.f);
    return e;
}

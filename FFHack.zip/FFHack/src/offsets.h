#pragma once
#include <cstdint>

// ── Atualizar com Il2CppDumper apos cada patch do FF ─────────────
namespace OFF {
    constexpr uintptr_t GAME_OBJECT_MANAGER  = 0x04A2C3D0;
    constexpr uintptr_t LOCAL_PLAYER         = 0x04A2B3D8;
    constexpr uintptr_t ENTITY_LIST          = 0x04A2C420;
    constexpr uintptr_t ENTITY_COUNT         = 0x04A2C424;
    constexpr uintptr_t VIEW_PROJ_MATRIX     = 0x05C40210;

    constexpr uintptr_t ENT_TRANSFORM        = 0x28;
    constexpr uintptr_t ENT_HP               = 0x1A0;
    constexpr uintptr_t ENT_MAX_HP           = 0x1A4;
    constexpr uintptr_t ENT_NAME             = 0x68;
    constexpr uintptr_t ENT_TEAM_ID          = 0x190;

    constexpr uintptr_t BONE_HEAD            = 0x1C8;
    constexpr uintptr_t BONE_ROOT            = 0x228;

    constexpr uintptr_t RECOIL_VEC           = 0x2B0;
    constexpr uintptr_t SPREAD_MULT          = 0x2B8;

    constexpr uintptr_t LOCAL_TRANSFORM      = 0x28;
    constexpr uintptr_t TRANSFORM_POS        = 0x90;
    constexpr uintptr_t LOCAL_VIEW_ANGLE     = 0x2C0;
}

#pragma once
#include <cmath>

struct Vec2 { float x, y; };
struct Vec3 {
    float x, y, z;
    Vec3 operator-(const Vec3& o) const { return {x-o.x, y-o.y, z-o.z}; }
    float length() const { return sqrtf(x*x + y*y + z*z); }
};

struct Matrix4x4 { float m[4][4]; };

inline bool WorldToScreen(const Matrix4x4& vp, const Vec3& w,
                          Vec2& s, float sw, float sh) {
    float x = vp.m[0][0]*w.x + vp.m[0][1]*w.y + vp.m[0][2]*w.z + vp.m[0][3];
    float y = vp.m[1][0]*w.x + vp.m[1][1]*w.y + vp.m[1][2]*w.z + vp.m[1][3];
    float ww= vp.m[3][0]*w.x + vp.m[3][1]*w.y + vp.m[3][2]*w.z + vp.m[3][3];
    if (ww < 0.001f) return false;
    s = { (x/ww + 1.f)*0.5f * sw, (1.f - y/ww)*0.5f * sh };
    return true;
}

inline float Distance(const Vec3& a, const Vec3& b) { return (a - b).length(); }

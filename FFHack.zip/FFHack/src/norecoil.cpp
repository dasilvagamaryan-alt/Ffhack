#include "norecoil.h"
#include "config.h"
#include "memory.h"
#include "offsets.h"
#include "math.h"

extern uintptr_t g_localPlayer;

void NoRecoil_Tick() {
    if (!g_localPlayer) return;
    uintptr_t wc = Mem::readPtr(g_localPlayer + 0x380);
    if (!wc) return;
    if (Cfg::noRecoil)  Mem::write<Vec2>(wc + OFF::RECOIL_VEC,   {0.f, 0.f});
    if (Cfg::noSpread)  Mem::write<float>(wc + OFF::SPREAD_MULT,  0.f);
}

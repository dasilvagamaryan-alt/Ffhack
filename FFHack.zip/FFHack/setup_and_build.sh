#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════
#  FFHack — setup + build automático
#  Roda em Linux/Mac. No Windows usa WSL2 ou Git Bash.
#  Precisa de: git, cmake, ninja, unzip, wget ou curl
# ════════════════════════════════════════════════════════════════
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

RED='\033[0;31m'; GRN='\033[0;32m'; YLW='\033[1;33m'; NC='\033[0m'
info()  { echo -e "${GRN}[+]${NC} $*"; }
warn()  { echo -e "${YLW}[!]${NC} $*"; }
error() { echo -e "${RED}[x]${NC} $*"; exit 1; }

# ── 1. NDK ───────────────────────────────────────────────────────
NDK_VERSION="r25c"
NDK_DIR="$SCRIPT_DIR/ndk"
NDK_ZIP="android-ndk-${NDK_VERSION}-linux.zip"
NDK_URL="https://dl.google.com/android/repository/${NDK_ZIP}"

if [ -z "$ANDROID_NDK_HOME" ] || [ ! -d "$ANDROID_NDK_HOME" ]; then
    if [ ! -d "$NDK_DIR/android-ndk-${NDK_VERSION}" ]; then
        info "Baixando NDK $NDK_VERSION (~800MB)..."
        mkdir -p "$NDK_DIR"
        if command -v wget &>/dev/null; then
            wget -q --show-progress "$NDK_URL" -O "$NDK_DIR/$NDK_ZIP"
        else
            curl -L "$NDK_URL" -o "$NDK_DIR/$NDK_ZIP"
        fi
        info "Extraindo NDK..."
        unzip -q "$NDK_DIR/$NDK_ZIP" -d "$NDK_DIR"
        rm -f "$NDK_DIR/$NDK_ZIP"
    fi
    export ANDROID_NDK_HOME="$NDK_DIR/android-ndk-${NDK_VERSION}"
    info "NDK em: $ANDROID_NDK_HOME"
else
    info "NDK encontrado: $ANDROID_NDK_HOME"
fi

# ── 2. cmake + ninja check ───────────────────────────────────────
command -v cmake  &>/dev/null || error "cmake nao encontrado. Instala com: sudo apt install cmake"
command -v ninja  &>/dev/null || error "ninja nao encontrado. Instala com: sudo apt install ninja-build"
command -v git    &>/dev/null || error "git nao encontrado. Instala com: sudo apt install git"

# ── 3. Dobby ─────────────────────────────────────────────────────
DOBBY_DIR="$SCRIPT_DIR/external/Dobby"
if [ ! -d "$DOBBY_DIR" ]; then
    info "Clonando Dobby..."
    mkdir -p "$SCRIPT_DIR/external"
    git clone --depth=1 https://github.com/jmpews/Dobby.git "$DOBBY_DIR"
else
    info "Dobby ja presente"
fi

# ── 4. ImGui ─────────────────────────────────────────────────────
IMGUI_DIR="$SCRIPT_DIR/external/imgui"
if [ ! -d "$IMGUI_DIR" ]; then
    info "Clonando ImGui v1.90..."
    git clone --depth=1 --branch v1.90 https://github.com/ocornut/imgui.git "$IMGUI_DIR"
else
    info "ImGui ja presente"
fi

# ── 5. Build ─────────────────────────────────────────────────────
BUILD_DIR="$SCRIPT_DIR/build"
info "Configurando CMake..."
cmake -B "$BUILD_DIR" \
    -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake" \
    -DANDROID_ABI=arm64-v8a \
    -DANDROID_PLATFORM=android-28 \
    -DCMAKE_BUILD_TYPE=Release \
    -GNinja

info "Compilando..."
cmake --build "$BUILD_DIR" --target ffhack -j"$(nproc 2>/dev/null || sysctl -n hw.ncpu)"

SO="$BUILD_DIR/libffhack.so"
if [ -f "$SO" ]; then
    cp "$SO" "$SCRIPT_DIR/libffhack.so"
    info "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    info " BUILD OK  →  libffhack.so na raiz da pasta"
    info "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    info " PROXIMO PASSO: veja README_SIMPLES.txt"
else
    error "Build falhou — verifica erros acima"
fi
